<?php

/*
Plugin Name: Cyanisme Shell
Description: Cyanisme Shell
Version: 1.0
Author: Cyanisme
*/

echo "Hello World";
?>